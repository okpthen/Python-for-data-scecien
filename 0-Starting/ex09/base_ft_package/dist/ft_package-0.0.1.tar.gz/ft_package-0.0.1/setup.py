from setuptools import setup, find_packages


setup(
    name="ft_package",
    version='0.0.1',
    description='A sample test package',
    author="ocartier",
    author_email="ocartier@42.fr",
    packages=find_packages(),
    liscence='MIT'
)
